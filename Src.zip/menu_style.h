#pragma once

#include "imgui/imgui.h"
#include "menu.h"

#define WINDOW_WIDTH  750
#define WINDOW_HEIGHT 380

void ApplyStyle()
{


	ImGui::GetMouseCursor();
	ImGui::SetMouseCursor(ImGuiMouseCursor_Arrow);
	ImGui::GetIO().WantCaptureMouse = Menu::Open;
	ImGui::GetIO().MouseDrawCursor = Menu::Open;

	auto& style = ImGui::GetStyle();


	style.FrameBorderSize					= 0;
	style.WindowRounding				    = 4;
	style.TabRounding						= 5;
	style.ScrollbarRounding					= 8;
	style.ChildRounding = 7.0f;
	style.FrameRounding = 5.0f;
	style.GrabRounding = 5.0f;
	style.PopupRounding = 5.0f;
	style.FramePadding = ImVec2(8, 6);
	style.WindowTitleAlign = ImVec2(0.0f, 0.5f);

	style.Colors[ImGuiCol_TitleBg]		     = ImColor(255, 0, 0, 255);			// The top bar color
	style.Colors[ImGuiCol_TitleBgActive]	 = ImColor(255, 0, 0, 255);			// When you press in the imgui menu
	style.Colors[ImGuiCol_TitleBgCollapsed]  = ImColor(15, 15, 15, 50);		        // When the title is collapsed
	style.Colors[ImGuiCol_Scheme]			 = ImColor(21, 82, 189, 255);
	style.Colors[ImGuiCol_WindowBg]			 = ImColor(0 ,0 ,15, 255);				// Window Background
	style.Colors[ImGuiCol_ChildBg]			 = ImVec4(ImColor(9, 9, 24, 175));
	style.Colors[ImGuiCol_Button]			 = ImColor(32, 41, 67, 255);			// button color
	style.Colors[ImGuiCol_ButtonActive]		 = ImColor(32, 41, 67);	        // button color when pressed
	style.Colors[ImGuiCol_ButtonHovered]	 = ImColor(32, 41, 67);		    // button when hovered

	style.Colors[ImGuiCol_CheckMark]		 = ImColor(255, 255, 255, 255);			//check mark color
	style.Colors[ImGuiCol_Text]				 = ImColor(255, 255, 255, 255);
	style.Colors[ImGuiCol_FrameBg]	         = ImColor(32, 41, 67, 255);
	style.Colors[ImGuiCol_FrameBgActive]	 = ImColor(32, 41, 67, 255);
	style.Colors[ImGuiCol_FrameBgHovered]	 = ImColor(32, 41, 67, 255);
	style.Colors[ImGuiCol_PopupBg]			 = ImColor(32, 41, 67, 255);
	
	style.Colors[ImGuiCol_SliderGrab]		 = ImColor(255, 255, 255, 255);
	style.Colors[ImGuiCol_SliderGrabActive]  = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);

	style.Colors[ImGuiCol_Header]			 = ImColor(32, 41, 67, 255);			// for collapsing headers , etc
	style.Colors[ImGuiCol_HeaderActive]		 = ImColor(32, 41, 67, 255);
	style.Colors[ImGuiCol_HeaderHovered]	 = ImColor(41, 50, 76, 255);

	style.Colors[ImGuiCol_ResizeGrip]		 = ImColor(51, 49, 50, 255);		    // the resize grip thing bottom right
	style.Colors[ImGuiCol_ResizeGripActive]  = ImColor(54, 53, 55);			// when you hold it / active
	style.Colors[ImGuiCol_ResizeGripHovered] = ImColor(51, 49, 50, 255);			// when you hover over it



	style.Colors[ImGuiCol_Separator]		 = ImColor(54, 54, 54);
	style.Colors[ImGuiCol_SeparatorActive]   = ImColor(54, 54, 54);
	style.Colors[ImGuiCol_SeparatorHovered]  = ImColor(54, 54, 54);

}