#pragma once

#include "imgui/imgui_internal.h"
#include "imgui/imgui.h"




namespace Menu
{
	static bool Open = true; 
	static bool FirstTime = true; 
	static int Tab = 0; 
	static int SubTab = 0; 
	inline int menu_key = 0x2E; 
	//void Style(void); 
	//void Drawing(void) ;

	static ImFont* BiggestIcon; 
	static ImFont* BiggestFont; 
	static ImFont* littleFont; 


}