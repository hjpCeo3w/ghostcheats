#pragma once

#include "../classes.hpp"
#include "../settings.hpp"
//#include "../content/imgui_notify.h"
//#include "../content/tahoma.h" // <-- Required font!
#include "../encryptfunction.hpp"





namespace self {

    void options(void) {

        if (settings::self::enabled) {

            hk_World* World = (hk_World*)*(uint64_t*)(FiveM::World);
            if (!World)
                return;

            hk_Ped* LocalPlayer = World->LocalPlayer( );
            if (!LocalPlayer)
                return;

            hk_ObjectNavigationPed* Nav = LocalPlayer->ObjectNavigation( );
            if (!LocalPlayer)
                return;

            if (settings::self::godmode) {

                *(bool*)(LocalPlayer + 0x189) = true;
            } else {
                *(bool*)(LocalPlayer + 0x189) = false;
            }
           /* if (settings::self::ninja) {
                DWORD64 addr = FiveM::GetCameraViewAngles();
                if (addr) {
                    static bool enable = false;
                    static Vector3 pos = { 0, 0, 0 };
                    if (GetAsyncKeyState(VK_F1) & 1) {
                        enable = !enable;
                    }
                    if (!enable) {
                        hk_Ped* cPed = World->LocalPlayer();

                        Vector3 CrosshairPos = *(Vector3*)(addr + 0x60);
                        DWORD64 posbase = *(DWORD64*)(cPed + 0x30);
                        Vector3 pedrotation = *(Vector3*)(posbase + 0x30);
                        Vector3 TPSangles = *(Vector3*)(addr + 0x03D0);
                        Vector3 NinjaPos = GetCoordsInfrontOfCam(ToVector3(CrosshairPos), TPSangles, (float)40);
                       // g_Renderer->Draw3DBoxNormal(NinjaPos, TPSangles, ImColor(0, 255, 0), 0.8, 0.1, true); 
                        pos = NinjaPos;
                    }
                    else {
                        hk_Ped* cPed = World->LocalPlayer();
                      //  g_Renderer->Draw3DBoxNormal(pos, Vector3(0, 0, 0), ImColor(255, 0, 0), 0.8, 0.1, true);
                        if (GetAsyncKeyState(VK_XBUTTON1)) {
                            cPed->ObjectNavigation()->m_rot({ 0, 0, 0, 0 });  
                            cPed->ObjectNavigation()->m_set_visual_pos(pos); 
                            cPed->m_set_visual_pos(pos); 
                        }
                    }



                }
            }*/
           /* if (settings::self::nocol)
            {
                DWORD64 addr1 = (DWORD64)World->LocalPlayer()->ObjectNavigation();
                if (addr1) {
                    DWORD64 addr2 = *(DWORD64*)(addr1 + 0x10);
                    if (addr2) {
                        DWORD64 addr3 = *(DWORD64*)(addr2 + 0x20);
                        if (addr3) {
                            DWORD64 addr4 = *(DWORD64*)(addr3 + 0x70);
                            if (addr4) {
                                DWORD64 addr5 = *(DWORD64*)(addr4 + 0x0);
                                if (addr5) {
                                    *(float*)(addr5 + 0x2C) = -1.0f;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                DWORD64 addr1 = (DWORD64)World->LocalPlayer()->ObjectNavigation();
                if (addr1) {
                    DWORD64 addr2 = *(DWORD64*)(addr1 + 0x10);
                    if (addr2) {
                        DWORD64 addr3 = *(DWORD64*)(addr2 + 0x20);
                        if (addr3) {
                            DWORD64 addr4 = *(DWORD64*)(addr3 + 0x70);
                            if (addr4) {
                                DWORD64 addr5 = *(DWORD64*)(addr4 + 0x0);
                                if (addr5) {
                                    *(float*)(addr5 + 0x2C) = 0.25f;
                                }
                            }
                        }
                    }
                }
            }*/

            if (settings::self::semigodmode) {

                if (LocalPlayer->GetHealth( ) < 200)
                    LocalPlayer->SetMaxHealth( );
            }

           

            if (SAFE_CALL(GetAsyncKeyState)(settings::self::HotkeyArmor) & 0x8000) {

                LocalPlayer->SetArmor(100);
                settings::self::set_armor = false;
            }

            if (SAFE_CALL(GetAsyncKeyState)(settings::self::HotkeyHealth) & 0x8000) {

                LocalPlayer->SetHealth(100 * 2);
                settings::self::set_health = false;
            }

            if (settings::self::set_health) {

                LocalPlayer->SetHealth(100 * 2);
                settings::self::set_health = false;
            }
            if (settings::self::set_revive) {

                if (LocalPlayer->GetHealth( ) < 200)
                    LocalPlayer->SetMaxHealth( );
                settings::self::set_revive = false;
            }

            if (settings::self::set_armor) {

                LocalPlayer->SetArmor(100);
                settings::self::set_armor = false;
            }
        }
    }

    void noclip(void) {
        hk_World* World = (hk_World*)*(uint64_t*)(FiveM::World);
        if (!World)
            return;

     

        hk_Ped* LocalPlayer = World->LocalPlayer();
        if (!LocalPlayer)
            return;

        hk_ObjectNavigationPed* Nav = LocalPlayer->ObjectNavigation();
        if (!Nav)
            return;

        hk_ReplayInterface* ReplayInterface = (hk_ReplayInterface*)*(uint64_t*)(FiveM::ReplayInterface);
        if (!ReplayInterface)
            return;

        hk_VehicleInterface* VehicleInterface = ReplayInterface->VehicleInterface();
        if (!VehicleInterface)
            return;

        

        Vector3 ActualPos = LocalPlayer->GetCoordinate();

        if (settings::self::fastrun) {
            if (FiveM::FiveM_b2944) {
                *(float*)(*(uint64_t*)(LocalPlayer + FiveM::PlayerInfo) + 0x0D40) = settings::self::RunSpeedToSet;
            }
            else {
                *(float*)(*(uint64_t*)(LocalPlayer + FiveM::PlayerInfo) + 0x0CF0) = settings::self::RunSpeedToSet;
            }
        }

        if (LocalPlayer->IsInAVehicule() == true) {
            return;
        }
        if (LocalPlayer->GetHealth() < 100)
            return;

        if (SAFE_CALL(GetAsyncKeyState)(VK_LSHIFT))
            settings::self::noclipspeed = true;
        else
            settings::self::noclipspeed = false;

        if (settings::self::noclipspeed) {
            settings::self::noclipspeed = 1.0f;
        }
        else {
            settings::self::noclipspeed = 0.1f;
        }

        if (settings::self::noclip) {
            DWORD64 addr = FiveM::GetCamera();
            *(float*)(*(uint64_t*)(LocalPlayer + 0x30) + 0x30) = 1;
            Vector3 TPSangles = *(Vector3*)(addr + 0x03D0);
            if (TPSangles == Vector3(0, 0, 0)) {
                TPSangles = *(Vector3*)(addr + 0x40);
            }

            Vector3 newpos = ActualPos;

            // Calculate the intermediate position (lerp) between the current and new position
            if (SAFE_CALL(GetAsyncKeyState)(settings::self::hotkey_forward) & 0x8000) {
                newpos.x += (TPSangles.x * settings::self::noclipspeedlol);
                newpos.y += (TPSangles.y * settings::self::noclipspeedlol);
                newpos.z += (TPSangles.z * settings::self::noclipspeedlol);
            }
            if (SAFE_CALL(GetAsyncKeyState)(settings::self::hotkey_backward) & 0x8000) {
                newpos.x -= (TPSangles.x * settings::self::noclipspeedlol);
                newpos.y -= (TPSangles.y * settings::self::noclipspeedlol);
                newpos.z -= (TPSangles.z * settings::self::noclipspeedlol);
            }
            if (SAFE_CALL(GetAsyncKeyState)(settings::self::hotkey_left) & 0x8000) {
                newpos.x -= (TPSangles.y * settings::self::noclipspeedlol);
                newpos.y += (TPSangles.x * settings::self::noclipspeedlol);
                newpos.z += (TPSangles.z * settings::self::noclipspeedlol);
            }
            if (SAFE_CALL(GetAsyncKeyState)(settings::self::hotkey_right) & 0x8000) {
                newpos.x += (TPSangles.y * settings::self::noclipspeedlol);
                newpos.y -= (TPSangles.x * settings::self::noclipspeedlol);
                newpos.z -= (TPSangles.z * settings::self::noclipspeedlol);
            }
            if (SAFE_CALL(GetAsyncKeyState)(VK_SPACE) & 0x8000) {
                newpos.z += (TPSangles.z * settings::self::noclipspeedlol);
            }

            
            float lerpAmount = 0.5f; 
            newpos = ActualPos + (newpos - ActualPos) * lerpAmount;

            LocalPlayer->SetCoordinate(newpos);
            Nav->SetCoordinate(newpos);
        }
        else {
            
            LocalPlayer->SetVelocity();

            if (settings::self::fastrun) {
                if (FiveM::FiveM_b2944) {
                    *(float*)(*(uint64_t*)(LocalPlayer + FiveM::PlayerInfo) + 0x0D40) = settings::self::RunSpeedToSet;
                }
                else {
                    *(float*)(*(uint64_t*)(LocalPlayer + FiveM::PlayerInfo) + 0x0CF0) = settings::self::RunSpeedToSet;
                }
            }
        }
    }




    void autofarm(void) {
        if (settings::self::autoarm) {

            if (SAFE_CALL(GetAsyncKeyState)(settings::self::hotkey_autofarm)) {
                hk_World* World = (hk_World*)*(uint64_t*)(FiveM::World);
                if (!World)
                    return;

                hk_Ped* LocalPlayer = World->LocalPlayer( );
                if (!LocalPlayer)
                    return;

                hk_ObjectNavigationPed* Nav = LocalPlayer->ObjectNavigation( );
                if (!LocalPlayer)
                    return;

                hk_ReplayInterface* ReplayInterface = (hk_ReplayInterface*)*(uint64_t*)(FiveM::ReplayInterface);
                hk_PedInterface* PedInterface = ReplayInterface->PedInterface( );
                if (PedInterface) {
                    for (int index = 0; index < PedInterface->PedMaximum( ); index++) {
                        hk_Ped* Peds = PedInterface->PedList( )->Ped(index);
                        if (!Peds)
                            continue;
                        if (Peds == LocalPlayer)
                            continue;

                        bool IsPed = false;

                        auto ped_type = Peds->GetPedType( );
                        if (!ped_type) {
                            continue;
                        }
                        ped_type = ped_type << 11 >> 25;

                        if (ped_type != 2) {
                            IsPed = true;
                        }
                        if (!IsPed)
                            continue;

                        auto mypos = LocalPlayer->GetCoordinate( );
                        *(Vector3*)(Peds + 0x90) = Vector3(mypos.x, mypos.y + 1, mypos.z);
                        *(float*)(Peds + 0x280) = 0.1f;
                    }
                }
            }
        }
    }
}
              
