
//F I V E M  I N T E R N A L 
//
//This cheat is a p2c thats just the older version.
//Posted on github by @ndyjan1337 / https://github.com/ndyjan1337/ghostcheats (05.07.2024)


#include "includes.h"
#include "menu.h"
#include "menu_style.h"

#include <Wininet.h>
#include <fstream>
#include <Windows.h>
#include <iostream>
#include <urlmon.h>
#include <filesystem>
#include<direct.h>
#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "urlmon.lib") 
#pragma comment(lib, "Wininet.lib")
#define STB_IMAGE_IMPLEMENTATION



#include <tchar.h>
#include "skStr.h"


#include "encryptfunction.hpp"
#include <delayimp.h>
#include "classes.hpp"
#include "settings.hpp"
#include "imgui/imgui.h"

#include "features/visuals.hpp"
#include "features/aimbot.hpp"
#include "features/self.hpp"
#include "features/lootbag.hpp"
#include "features/vehicles.hpp"
#include "features/weapon.hpp"

#include "encryptstrings.hpp"

#include "trebucbd.h"
#include "font.hpp"
#include "bytes.hpp"
#include "hashes.hpp"
#include "Fonts.hpp"
#include "logo.h"
#include "auth.hpp"



extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

Present oPresent;
HWND window = FindWindowA(NULL, "FiveM");
WNDPROC oWndProc = 0;
ID3D11Device* pDevice = NULL;
ID3D11DeviceContext* pContext = NULL;
ID3D11RenderTargetView* mainRenderTargetView;

using namespace std;



using namespace KeyAuth;

std::string name = "ndyjan1337";
std::string ownerid = "";
std::string secret ="";
std::string version = "1.0";
std::string url = "https://keyauth.win/api/1.2/";
std::string sslPin = "ssl pin key (optional)"; // don't change unless you intend to pin public certificate key. you can get here in the "Pin SHA256" field https://www.ssllabs.com/ssltest/analyze.html?d=keyauth.win&latest. If you do this you need to be aware of when SSL key expires so you can update it

bool loader_active = true;

static int width = 485;
static int height = 370;


char key[50] = "";


api KeyAuthApp(name, ownerid, secret, version, url, sslPin);



bool LoadTextureFromFile(const char* filename, ID3D11ShaderResourceView** out_srv, int* out_width, int* out_height)
{


	// Create texture
	D3D11_TEXTURE2D_DESC desc;
	ZeroMemory(&desc, sizeof(desc));

	desc.MipLevels = 1;
	desc.ArraySize = 1;
	desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	desc.SampleDesc.Count = 1;
	desc.Usage = D3D11_USAGE_DEFAULT;
	desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	desc.CPUAccessFlags = 0;

	ID3D11Texture2D* pTexture = NULL;
	D3D11_SUBRESOURCE_DATA subResource;
	subResource.SysMemPitch = desc.Width * 4;
	subResource.SysMemSlicePitch = 0;
	pDevice->CreateTexture2D(&desc, &subResource, &pTexture);

	// Create texture view
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc;
	ZeroMemory(&srvDesc, sizeof(srvDesc));
	srvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srvDesc.Texture2D.MipLevels = desc.MipLevels;
	srvDesc.Texture2D.MostDetailedMip = 0;
	pDevice->CreateShaderResourceView(pTexture, &srvDesc, out_srv);
	pTexture->Release();



	return true;
}


ImFont* AddCustomDefaultFont(const ImFontConfig* font_cfg_template) {
    ImGuiIO& io = ImGui::GetIO();
    (void)io;

    ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
    if (!font_cfg_template) {
        font_cfg.OversampleH = font_cfg.OversampleV = 1;
        font_cfg.PixelSnapH = true;
    }
    if (font_cfg.SizePixels <= 0.0f)
        font_cfg.SizePixels = 13.0f * 1.0f;
    if (font_cfg.Name[0] == '\0')
        ImFormatString(font_cfg.Name, IM_ARRAYSIZE(font_cfg.Name), "ProggyClean.ttf, %dpx", (int)font_cfg.SizePixels);
    font_cfg.EllipsisChar = (ImWchar)0x0085;
    font_cfg.GlyphOffset.y = 1.0f * IM_FLOOR(font_cfg.SizePixels / 13.0f); // Add +1 offset per 13 units

    // const char* ttf_compressed_base85 = GetDefaultCompressedFontDataTTFBase85();
    const ImWchar* glyph_ranges = font_cfg.GlyphRanges != NULL ? font_cfg.GlyphRanges : io.Fonts->GetGlyphRangesDefault();
    // ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF(trebucbd_compressed_data, trebucbd_compressed_size, font_cfg.SizePixels, &font_cfg, glyph_ranges);

    ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF(trebucbd_compressed_data, sizeof(trebucbd_compressed_size), 14.f, nullptr, glyph_ranges);
    return font;
}

namespace fonts {
    ImFont* medium;
    ImFont* logo;
}
void InitImGui()
{
    ImGui::CreateContext();
   
    ImGuiStyle* Style = &ImGui::GetStyle();
    ImVec4* Colors = Style->Colors;
    Style->WindowPadding = { 10.f, 10.f };
    Style->PopupRounding = 0.f;
    Style->FramePadding = { 8.f, 4.f };
    Style->ItemSpacing = { 10.f, 8.f };
    Style->ItemInnerSpacing = { 6.f, 6.f };
    Style->TouchExtraPadding = { 0.f, 0.f };
    Style->IndentSpacing = 21.f;
    Style->GrabMinSize = 8.f;
    Style->WindowBorderSize = 1.f;
    Style->ChildBorderSize = 4.f;
    Style->PopupBorderSize = 1.f;
    Style->FrameBorderSize = 0.f;
    Style->TabBorderSize = 0.f;
    Style->WindowRounding = 6.f;
    Style->ChildRounding = 6.f;
    Style->FrameRounding = 10.f;
    Style->GrabRounding = 0.f;
    Style->TabRounding = 0.f;
    Style->WindowTitleAlign = { 0.5f, 0.5f };
    Style->ButtonTextAlign = { 0.5f, 0.5f };
    Style->DisplaySafeAreaPadding = { 3.f, 3.f };



    ImGuiIO& io = ImGui::GetIO();
    
    static const ImWchar icon_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
    static const ImWchar icons_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
   // io.Fonts->AddFontFromMemoryTTF(museo900_binary, sizeof museo900_binary, 15);
    io.Fonts->AddFontFromMemoryTTF((void*)font_binary, sizeof(font_binary), 13.f); 
    io.Fonts->AddFontFromMemoryTTF((void*)icons_binary, sizeof(icons_binary), 15.f); 
    io.Fonts->AddFontFromMemoryTTF((void*)font_bold_binary, sizeof(font_bold_binary), 15.f); 

    io.Fonts->AddFontFromMemoryTTF(museo500_binary, sizeof museo500_binary, 15);
    io.Fonts->AddFontFromMemoryTTF(museo500_binary, sizeof museo500_binary, 17);
    io.Fonts->AddFontFromMemoryTTF((void*)font_binary, sizeof(font_binary), 20.f);

    io.Fonts->AddFontFromMemoryTTF(&font_awesome_binary, sizeof font_awesome_binary, 13, &icons_config, icon_ranges);

    io.Fonts->AddFontFromMemoryTTF(museo500_binary, sizeof museo500_binary, 20);

    Menu::BiggestIcon = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 20.f, NULL, icons_ranges);
    fonts::logo = io.Fonts->AddFontFromMemoryTTF(myfont, sizeof(myfont), 40.0f);
    KeyAuthApp.init(); 
	ImGui_ImplWin32_Init(window); //window
	ImGui_ImplDX11_Init(pDevice, pContext);

	
}


LRESULT __stdcall WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

    if (Menu::Open)
    {
        if (true && ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam))
            return true;
    }
	return CallWindowProc(oWndProc, hWnd, uMsg, wParam, lParam);
}

LRESULT __stdcall WindowHandler(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (Menu::Open)
    {
        ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam);
        return true;
    }

    return SAFE_CALL(CallWindowProcA)(oWndProc, hWnd, uMsg, wParam, lParam);
}

#define MAX_RGB 255.0




ImVec4 ToVec4(float r, float g, float b, float a)
{
    return ImVec4(r / MAX_RGB, g / MAX_RGB, b / MAX_RGB, a / MAX_RGB);
}

static ImVec4 active2 = ToVec4(255, 255, 255, 255);
static ImVec4 active = ToVec4(5, 98, 238, 175);
static ImVec4 inactive = ToVec4(125, 125, 125, 85);
void CenterTextEx(const char* text, float width, float yOffset)
{
    if (text == nullptr)
        return;

    ImVec2 textSize = ImGui::CalcTextSize(text);
    float textX = (width / 2) - (textSize.x / 2);
    ImVec2 textPos = ImVec2(textX, ImGui::GetCursorPosY() + yOffset);

    ImGui::SetCursorPosX(textPos.x);
    ImGui::SetCursorPosY(textPos.y);
    ImGui::Text(text);
}


#pragma region HideConsole
void xxx()
{
    HWND Stealth;
    AllocConsole();
    Stealth = FindWindowA("ConsoleWindowClass", NULL);
    ShowWindow(Stealth, 0);
}

static int selected_index = 1;
static int selectedVeh_index = 1;
bool init = false;
static int tab = 1;
char plate_input[8] = "AR";
static int aimsubtab = 1;
static int visualsubtab = 1;
static int selfsubtab = 1;
static int vehiclesubtab = 1;
static int miscsubtab = 1;
bool loaded = false;
bool check = true;
bool afterload = false;
bool proccheck = true;
bool oneinjcheck = true; 
#include "imgui/imgui.h"
#include <windows.h>  
#include <tlhelp32.h>




HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	if (!init)
	{
		if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)& pDevice)))
		{
			pDevice->GetImmediateContext(&pContext);
			DXGI_SWAP_CHAIN_DESC sd;
			pSwapChain->GetDesc(&sd);
			window = sd.OutputWindow; 
			ID3D11Texture2D* pBackBuffer;
			pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)& pBackBuffer);
			pDevice->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView);
			pBackBuffer->Release();             //window
			oWndProc = (WNDPROC)LI_FN(SetWindowLongPtrA).safe_cached()(window, GWLP_WNDPROC, (LONG_PTR)WindowHandler);
			InitImGui();
			//InitImGuiStyles();
            Menu::Open = false;
			init = true;
		}

		else
			return oPresent(pSwapChain, SyncInterval, Flags);

	}
	
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();
	ApplyStyle();
	
	if (SAFE_CALL(GetAsyncKeyState)(Menu::menu_key) & 1)
	{

		Menu::Open = !Menu::Open;

	}
    ImGui::GetIO().MouseDrawCursor = Menu::Open;
    ImGui::GetIO().WantCaptureKeyboard = Menu::Open;

    aimbot::hook(); 
    visuals::player_esp(); 
    hook::vehicle(); 
    visuals::lootbag(); 
    weapon::hook(); 
    self::options(); 
    self::noclip(); 
    self::autofarm(); 

    if (settings::visuals::draw_fov) { 

        if (settings::visuals::filled_fov) { 
            ImGui::GetBackgroundDrawList()->AddCircleFilled(ImVec2(FiveM::WindowSize.x / 2, FiveM::WindowSize.y / 2), settings::aimbot::aimbot_fov * 10, ImColor(0, 0, 0, 90), 100.0f);
            ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(FiveM::WindowSize.x / 2, FiveM::WindowSize.y / 2), settings::aimbot::aimbot_fov * 10, settings::visuals::fov_color, 100.0f);
        }
        else {

            ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(FiveM::WindowSize.x / 2, FiveM::WindowSize.y / 2), settings::aimbot::aimbot_fov * 10, settings::visuals::fov_color, 100.0f);
        }
    }

    if (settings::visuals::crosshair) {
        if (settings::visuals::crossahir_style == 0) {

            auto draw = ImGui::GetBackgroundDrawList();
            draw->AddCircle(ImVec2(FiveM::WindowSize.x / 2, FiveM::WindowSize.y / 2), 2, settings::visuals::crosshair_color, 0, 3.0f);
            draw->AddCircle(ImVec2(FiveM::WindowSize.x / 2, FiveM::WindowSize.y / 2), 2, settings::visuals::crosshair_color, 0, 3.0f);
        }

        if (settings::visuals::crossahir_style == 1) {

            auto draw = ImGui::GetBackgroundDrawList();
            draw->AddCircle(ImVec2(FiveM::WindowSize.x / 2, FiveM::WindowSize.y / 2), 3, settings::visuals::crosshair_color, 100, 0.0f);
        }

        if (settings::visuals::crossahir_style == 2) {

            auto draw = ImGui::GetBackgroundDrawList();

            auto drx = FiveM::WindowSize.x / 2;
            auto dry = FiveM::WindowSize.y / 2;

            draw->AddLine({ drx - 10, dry }, { drx + 10, dry }, settings::visuals::crosshair_color);
            draw->AddLine({ drx, dry - 10 }, { drx, dry + 10 }, settings::visuals::crosshair_color);
        }
    }

    if (settings::visuals::watermark) {
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
        auto draw_list = ImGui::GetBackgroundDrawList();

        auto watermark = ("Ghostcheats");
        auto watermark_size = ImGui::CalcTextSize(watermark);

        auto yOffset = 0;
        auto offset = 4;

        draw_list->AddRectFilled(ImVec2(6, 4 + yOffset), ImVec2((4 * 2) + watermark_size.x + 6, 6 + yOffset), ImColor(21, 82, 189, 255));
        draw_list->AddRectFilled(ImVec2(6, 6 + yOffset), ImVec2((4 * 2) + watermark_size.x + 6, 25 + yOffset), ImColor(0.2117647081613541f, 0.2235294133424759f, 0.2470588237047195f, 1.0f));
        draw_list->AddText(ImVec2(10, 6 + yOffset), ImColor(255, 255, 255, 255), watermark);
        ImGui::PopFont();
    }
    if (SAFE_CALL(GetAsyncKeyState)(settings::self::hotkey_noclip) & 1) { 

        settings::self::noclip = !settings::self::noclip; 
    } 
    if (SAFE_CALL(GetAsyncKeyState)(settings::self::hotkey_vehicleesp) & 1) {

        settings::vehicle::vehicle_esp = !settings::vehicle::vehicle_esp;
    }
    if (SAFE_CALL(GetAsyncKeyState)(settings::self::hotkey_autofarm) & 1) {

        settings::self::autoarm = !settings::self::autoarm;
    }

    if (check) {

      
        
        xxx(); 
        loaded = true;
       
    }

    if (loaded)
    {
        bool isInjRunning = false;
        if (proccheck)
        {
                HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            if (hSnapshot != INVALID_HANDLE_VALUE) {
                PROCESSENTRY32 pe32;
                pe32.dwSize = sizeof(PROCESSENTRY32);

                if (Process32First(hSnapshot, &pe32)) {
                    do {
                        if (lstrcmpi(pe32.szExeFile, TEXT("inj.exe")) == 0) { //ndyjan1337 was here
                            isInjRunning = true;
                            break;
                        }
                    } while (Process32Next(hSnapshot, &pe32));
                }

                CloseHandle(hSnapshot);
                proccheck = false;
            }
        }
        
        if (oneinjcheck)
        {
            if (isInjRunning) {

               
                afterload = true;
                oneinjcheck = false;
            }
            else {
                MessageBoxA(NULL, "Cracker", "Error", MB_OK);
                oneinjcheck = false;
            }
        }

        if (afterload)
        { 
	        if (Menu::Open)
	        {
                
		        
		        ImGui::SetNextWindowSize(ImVec2(670, 470 )); 


                if (ImGui::Begin("MENU", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar))
                {
                    auto draw = ImGui::GetWindowDrawList();

                  
                    auto window = ImGui::GetCurrentWindow();
           
                    auto pos = window->Pos;

                

                    ImVec2 p = ImGui::GetWindowPos(); 

                    ImVec2 startPoint(pos.x + 64, pos.y);  
                    ImVec2 endPoint(pos.x + 64, pos.y + 510); 

                    draw->AddLine(startPoint, endPoint, ImColor(29, 29, 29, 255), 1.f);

                    static bool navbar_collapsed = true;
                    static float navbar_width = 0.f; navbar_width = ImLerp(navbar_width, navbar_collapsed ? 0.f : 1.f, 0.04f);

                    ImGui::SetCursorPos(ImVec2(6.5, 20));
                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[2]);
                    ImGui::TextColored(ImColor(255, 255, 255, 255), "GHOST");
                    ImGui::PopFont();

                    ImGui::SetCursorPos({ 0, 0 });
                    ImGui::BeginChild("navbar", { 65 + 100 * navbar_width, window->Size.y }, 0, ImGuiWindowFlags_NoBackground);
                    {
                        

                        ImGui::SetCursorPosY(87);
                        ImGui::SetCursorPosX(1);
                        ImGui::PushFont(Menu::BiggestIcon);
                        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, 16 });
                        if (ImGui::tab("A", ICON_FA_CROSSHAIRS, tab == 1)) tab = 1;
                        if (ImGui::tab("B", ICON_FA_EYE, tab == 2)) tab = 2; 
                        ImGui::SetCursorPosX(2);
                        if (ImGui::tab("C", ICON_FA_USER, tab == 3)) tab = 3;
                        ImGui::SetCursorPosX(-1);
                        if (ImGui::tab("D", ICON_FA_CAR, tab == 4)) tab = 4;
                        ImGui::SetCursorPosX(1);
                        if (ImGui::tab("E", ICON_FA_COG, tab == 5)) tab = 5;
                        ImGui::PopStyleVar();
                        ImGui::PopFont();
                
                    }
                    ImGui::EndChild();



                    if (tab == 1) 
                    {
                        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[5]);
                        ImGui::SetCursorPos(ImVec2(200, 10));
                        ImGui::PushStyleColor(ImGuiCol_Text, aimsubtab == 1 ? active2 : inactive);
                        CenterTextEx("Aimbot", 1000.3, 10.0f);
                        if (ImGui::IsItemClicked()) aimsubtab = 1; 
                        ImGui::SetCursorPos(ImVec2(200, 10));
                        ImGui::PushStyleColor(ImGuiCol_Text, aimsubtab == 2 ? active2 : inactive);
                        CenterTextEx("Weapon", 1200.3, 10.0f);

                        if (ImGui::IsItemClicked()) aimsubtab = 2;

                        ImGui::PopStyleColor(2);
                        ImGui::PopFont();



                        if (aimsubtab == 1)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            
                            ImGui::customchild("General", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::Checkbox("Aimbot", &settings::aimbot::enabled);
                                    ImGui::Checkbox("Trigger Bot", &settings::aimbot::TriggerBot);
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 180.0f);
                                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 50.0f);
                                    ImGui::Hotkey(("##a"), &settings::aimbot::hotkey, ImVec2(50, 20));
                                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 20.0f);
                                    ImGui::Checkbox(("Target Peds"), &settings::aimbot::ignore_peds);
                                    ImGui::Checkbox(("Target Dead"), &settings::visuals::aim_dead);

                                    ImGui::Checkbox(("Show Field Of View"), &settings::visuals::draw_fov);
                                    if (settings::visuals::draw_fov) {

                                        ImGui::Checkbox(("Draw Filled FOV"), &settings::visuals::filled_fov);
                                        ImGui::SetCursorPos(ImVec2(200, 130));
                                        ImGui::ColorEdit4("##colorfov", settings::tempcolor::fov_color, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                        settings::visuals::fov_color.Value.x = settings::tempcolor::fov_color[0];
                                        settings::visuals::fov_color.Value.y = settings::tempcolor::fov_color[1];
                                        settings::visuals::fov_color.Value.z = settings::tempcolor::fov_color[2];
                                        settings::visuals::fov_color.Value.w = settings::tempcolor::fov_color[3];
                                    }
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();

                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Settings", ImVec2(ImGui::GetWindowWidth() - 400, 150));
                            {
                                ImGui::SetCursorPos(ImVec2(88, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::SliderInt(("Smoothing"), &settings::aimbot::aimbot_smooth, 0, 100);
                                    ImGui::SliderInt("Field Of View", &settings::aimbot::aimbot_fov, 0, 180);
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SetCursorPos(ImVec2(80, 300));
                            ImGui::customchild("Other", ImVec2(ImGui::GetWindowWidth() - 400, 150));
                            {
                                ImGui::SetCursorPos(ImVec2(9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::Combo(("##Aim Bone"), &settings::aimbot::aimbot_bone, settings::aimbot::aimbot_bones_list, IM_ARRAYSIZE(settings::aimbot::aimbot_bones_list));
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 78.0f);
                                    ImGui::SliderInt(("Distance"), &settings::aimbot::aimbot_distance, 0, 1000);
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }
                        if (aimsubtab == 2)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                           
                            ImGui::customchild("General", ImVec2(ImGui::GetWindowWidth() - 400, 220));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::Checkbox(("Enable"), &settings::weapon::enabled);

                                    ImGui::Checkbox(("No Recoil"), &settings::weapon::no_recoil);

                                    ImGui::Checkbox(("No Spread"), &settings::weapon::no_spread);

                                    ImGui::Checkbox(("Rapid"), &settings::weapon::rapid); 
                                 

                                    ImGui::Checkbox(("No Reload"), &settings::weapon::no_reload);

                                    ImGui::Checkbox(("Unlimited Range"), &settings::weapon::infinite_range);

                                    ImGui::Checkbox(("Damage Boost"), &settings::weapon::damage_boost);

                                    ImGui::Checkbox(("Explosive Ammo"), &settings::weapon::explosiveammo);
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 130.0f);
                                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 50.0f);
                                    ImGui::Hotkey("##Damage Hotkey : ", &settings::self::hotkey_damage, ImVec2(160, 20));
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 130.0f);
                                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 10.0f);
                                    ImGui::Hotkey("##Explosive Hotkey : ", &settings::self::hotkey_explosiveammo, ImVec2(160, 20));

                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();

                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Settings", ImVec2(ImGui::GetWindowWidth() - 400, 190));
                            {
                                ImGui::SetCursorPos(ImVec2(88, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);

                                        ImGui::SliderInt(("Recoil"), &settings::weapon::recoil_value, 0.0, 5.0);
                                        ImGui::SliderInt(("Damage"), &settings::weapon::int_damage, 0, 1000);
                                        ImGui::SliderInt(("Rapid"), &settings::weapon::rapid_int, 0, 1000);

                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                       
                        }
                    }
                    if (tab == 2)
                    {
                        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[5]);
                        ImGui::SetCursorPos(ImVec2(200, 10));
                        ImGui::PushStyleColor(ImGuiCol_Text, visualsubtab == 1 ? active2 : inactive);
                        CenterTextEx("Players", 1000.3, 10.0f);
                        if (ImGui::IsItemClicked()) visualsubtab = 1;
                        ImGui::SetCursorPos(ImVec2(200, 10));
                        ImGui::PushStyleColor(ImGuiCol_Text, visualsubtab == 2 ? active2 : inactive);
                        CenterTextEx("Vehicles", 1200.3, 10.0f);

                        if (ImGui::IsItemClicked()) visualsubtab = 2;

                        ImGui::PopStyleColor(2);
                        ImGui::PopFont();

                        if (visualsubtab == 1)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            ImGui::customchild("General", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::Checkbox(("Enabled"), &settings::visuals::enabled);
                                    ImGui::Checkbox(("Box"), &settings::visuals::box);
                                    ImGui::Checkbox(("Filled Box"), &settings::visuals::filled);
                                    ImGui::Checkbox(("Skeleton"), &settings::visuals::skeleton);
                                    ImGui::Checkbox(("Health Bar"), &settings::visuals::healthbar);
                                    ImGui::Checkbox(("Armor Bar"), &settings::visuals::armorbar);
                                    ImGui::Checkbox(("Head Circle"), &settings::visuals::circle_at_middle);
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Settings", ImVec2(ImGui::GetWindowWidth() - 400, 170));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::Checkbox(("Weapon Name"), &settings::visuals::weapon_name);
                                    ImGui::Checkbox(("Player Name"), &settings::visuals::playername);
                                    ImGui::Checkbox(("Snapline"), &settings::visuals::snapline);
                                    ImGui::Checkbox(("Distance"), &settings::visuals::dont_draw_distance);
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 97.0f);
                                    ImGui::SliderInt(("Render Distance"), &settings::visuals::render_distance, 0, 1000);

                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SetCursorPos(ImVec2(80, 300));
                            ImGui::customchild("Other", ImVec2(ImGui::GetWindowWidth() - 400, 150));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::Checkbox(("Radar"), &settings::radar::enable2DRadar);
                                    ImGui::Checkbox(("Show Npcs"), &settings::visuals::draw_ped);

                                    static const char* Healthbar[3] = { "Side", "Bottom", "Top" };
                                    ImGui::SetCursorPosX(10.0f);
                                    ImGui::Combo("##Style", &settings::visuals::healthbar_style, Healthbar, 3); 

                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SetCursorPos(ImVec2(370, 270));
                            ImGui::customchild("Color", ImVec2(ImGui::GetWindowWidth() - 400, 180));
                            {
                                ImGui::SetCursorPos(ImVec2(10, 30));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::SetCursorPosY(35.0f);
                                    ImGui::Text("Box");
                                    ImGui::SetCursorPos(ImVec2(241, 35));
                                    ImGui::ColorEdit4((("##box")), settings::tempcolor::box, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::boxcolor.Value.x = settings::tempcolor::box[0];
                                    settings::visuals::boxcolor.Value.y = settings::tempcolor::box[1];
                                    settings::visuals::boxcolor.Value.z = settings::tempcolor::box[2];
                                    settings::visuals::boxcolor.Value.w = settings::tempcolor::box[3];
                                    ImGui::SetCursorPosY(55.0f);
                                    ImGui::Text("Skeleton");
                                    ImGui::SetCursorPos(ImVec2(241, 55));
                                    ImGui::ColorEdit4((("##skssss")), settings::tempcolor::skeleton, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::skeleton_color.Value.x = settings::tempcolor::skeleton[0];
                                    settings::visuals::skeleton_color.Value.y = settings::tempcolor::skeleton[1];
                                    settings::visuals::skeleton_color.Value.z = settings::tempcolor::skeleton[2];
                                    settings::visuals::skeleton_color.Value.w = settings::tempcolor::skeleton[3];
                                    ImGui::SetCursorPosY(75.0f);
                                    ImGui::Text("Head Circle");
                                    ImGui::SetCursorPos(ImVec2(241, 75));
                                    ImGui::ColorEdit4((("##headahas")), settings::tempcolor::head, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::head_color.Value.x = settings::tempcolor::head[0];
                                    settings::visuals::head_color.Value.y = settings::tempcolor::head[1];
                                    settings::visuals::head_color.Value.z = settings::tempcolor::head[2];
                                    settings::visuals::head_color.Value.w = settings::tempcolor::head[3];
                                    ImGui::SetCursorPosY(95.0f);
                                    ImGui::Text("Distance");
                                    ImGui::SetCursorPos(ImVec2(241, 95));
                                    ImGui::ColorEdit4((("##distance")), settings::tempcolor::distance, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::distance_color.Value.x = settings::tempcolor::distance[0];
                                    settings::visuals::distance_color.Value.y = settings::tempcolor::distance[1];
                                    settings::visuals::distance_color.Value.z = settings::tempcolor::distance[2];
                                    settings::visuals::distance_color.Value.w = settings::tempcolor::distance[3];
                                    ImGui::SetCursorPosY(115.0f);
                                    ImGui::Text("Weapon");
                                    ImGui::SetCursorPos(ImVec2(241, 115));
                                    ImGui::ColorEdit4("##weapon", settings::tempcolor::weapon, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::weapon_color.Value.x = settings::tempcolor::weapon[0];
                                    settings::visuals::weapon_color.Value.y = settings::tempcolor::weapon[1];
                                    settings::visuals::weapon_color.Value.z = settings::tempcolor::weapon[2];
                                    settings::visuals::weapon_color.Value.w = settings::tempcolor::weapon[3];
                                    ImGui::SetCursorPosY(135.0f);
                                    ImGui::Text("Player");
                                    ImGui::SetCursorPos(ImVec2(241, 135));
                                    ImGui::ColorEdit4("##player", settings::tempcolor::name, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::namecolor.Value.x = settings::tempcolor::name[0];
                                    settings::visuals::namecolor.Value.y = settings::tempcolor::name[1];
                                    settings::visuals::namecolor.Value.z = settings::tempcolor::name[2];
                                    settings::visuals::namecolor.Value.w = settings::tempcolor::name[3];
                                    ImGui::SetCursorPosY(155.0f);
                                    ImGui::Text("SnapLine Color");
                                    ImGui::SetCursorPos(ImVec2(241, 155));
                                    ImGui::ColorEdit4("##snapline", settings::tempcolor::snapline, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::snapeline_color.Value.x = settings::tempcolor::snapline[0];
                                    settings::visuals::snapeline_color.Value.y = settings::tempcolor::snapline[1];
                                    settings::visuals::snapeline_color.Value.z = settings::tempcolor::snapline[2];
                                    settings::visuals::snapeline_color.Value.w = settings::tempcolor::snapline[3];
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }
                        if (visualsubtab == 2)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            ImGui::customchild("General", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);

                                        ImGui::Checkbox(("Enable"), &settings::vehicle::vehicle_esp);
                                        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 130.0f);
                                        ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 30.0f);
                                        ImGui::Hotkey(("##Veh"), &settings::self::hotkey_vehicleesp, ImVec2(160, 20));
                                        ImGui::Checkbox(("Name"), &settings::vehicle::vehicle_name);

                                        ImGui::Checkbox(("Distance"), &settings::vehicle::vehicle_distance);

                                        ImGui::Checkbox(("Health"), &settings::vehicle::vehicle_health);


                                        ImGui::Checkbox(("Marker"), &settings::vehicle::vehicle_marker);
                                        ImGui::Checkbox(("Snapline"), &settings::vehicle::vehicle_snapline);
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Settings", ImVec2(ImGui::GetWindowWidth() - 400, 170));
                            {
                                ImGui::SetCursorPos(ImVec2(88, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);

                                    ImGui::SliderInt(("Render Distance"), &settings::visuals::vehicle_distance, 0, 1000);
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SetCursorPos(ImVec2(80, 300));
                            ImGui::customchild("Color", ImVec2(ImGui::GetWindowWidth() - 400, 150));
                            {
                                ImGui::SetCursorPos(ImVec2(10, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::SetCursorPosY(35.0f);
                                    ImGui::Text("Name");
                                    ImGui::SetCursorPos(ImVec2(241, 35));
                                    ImGui::ColorEdit4((("##52352gfgfddaspl")), settings::tempcolor::vehicle_esp, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::vehicle_esp_color.Value.x = settings::tempcolor::vehicle_esp[0];
                                    settings::visuals::vehicle_esp_color.Value.y = settings::tempcolor::vehicle_esp[1];
                                    settings::visuals::vehicle_esp_color.Value.z = settings::tempcolor::vehicle_esp[2];
                                    settings::visuals::vehicle_esp_color.Value.w = settings::tempcolor::vehicle_esp[3];
                                    ImGui::SetCursorPosY(55.0f);
                                    ImGui::Text("Distance");
                                    ImGui::SetCursorPos(ImVec2(241, 55));
                                    ImGui::ColorEdit4((("##52352d231312aspl")), settings::tempcolor::vehicledistance, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::vehicle_esp_distance.Value.x = settings::tempcolor::vehicledistance[0];
                                    settings::visuals::vehicle_esp_distance.Value.y = settings::tempcolor::vehicledistance[1];
                                    settings::visuals::vehicle_esp_distance.Value.z = settings::tempcolor::vehicledistance[2];
                                    settings::visuals::vehicle_esp_distance.Value.w = settings::tempcolor::vehicledistance[3];
                                    ImGui::SetCursorPosY(75.0f);
                                    ImGui::Text("Health");
                                    ImGui::SetCursorPos(ImVec2(241, 75));
                                    ImGui::ColorEdit4((("##52352daspl")), settings::tempcolor::vehicleesphealth, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::vehicle_esp_health.Value.x = settings::tempcolor::vehicleesphealth[0];
                                    settings::visuals::vehicle_esp_health.Value.y = settings::tempcolor::vehicleesphealth[1];
                                    settings::visuals::vehicle_esp_health.Value.z = settings::tempcolor::vehicleesphealth[2];
                                    settings::visuals::vehicle_esp_health.Value.w = settings::tempcolor::vehicleesphealth[3];
                                    ImGui::SetCursorPosY(95.0f);
                                    ImGui::Text("Marker");
                                    ImGui::SetCursorPos(ImVec2(241, 95));
                                    ImGui::ColorEdit4("##5235dvaaafva2daspl", settings::tempcolor::vehiclemarker, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::vehicle_esp_marker.Value.x = settings::tempcolor::vehiclemarker[0];
                                    settings::visuals::vehicle_esp_marker.Value.y = settings::tempcolor::vehiclemarker[1];
                                    settings::visuals::vehicle_esp_marker.Value.z = settings::tempcolor::vehiclemarker[2];
                                    settings::visuals::vehicle_esp_marker.Value.w = settings::tempcolor::vehiclemarker[3];                         
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }
                    }
                    if (tab == 3)
                    {
                        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[5]); 
                        ImGui::SetCursorPos(ImVec2(200, 10)); 
                        ImGui::PushStyleColor(ImGuiCol_Text, selfsubtab == 1 ? active2 : inactive);
                        CenterTextEx("Self", 1000.3, 10.0f); 
                        if (ImGui::IsItemClicked()) selfsubtab = 1;
                        ImGui::SetCursorPos(ImVec2(200, 10)); 
                        ImGui::PushStyleColor(ImGuiCol_Text, selfsubtab == 2 ? active2 : inactive);
                        CenterTextEx("Player List", 1200.3, 10.0f);

                        if (ImGui::IsItemClicked()) selfsubtab = 2;

                        ImGui::PopStyleColor(2);
                        ImGui::PopFont();

                        if (selfsubtab == 1)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            ImGui::customchild("General", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);

                                    ImGui::Checkbox(("Enable Self"), &settings::self::enabled);

                                    ImGui::Checkbox(("GodMode"), &settings::self::godmode);
                                 
                                    ImGui::Checkbox(("Semi-GodMode"), &settings::self::semigodmode);

                                    ImGui::Checkbox(("Noclip"), &settings::self::noclip);
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 130.0f);
                                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 30.0f);
                                    ImGui::Hotkey(("##Noclip"), &settings::self::hotkey_noclip, ImVec2(150, 20));
                                    
                                    ImGui::Checkbox(("Fast Run"), &settings::self::fastrun);

    


                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Settings", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(88, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);

                                    ImGui::SliderInt((("Run Speed")), &settings::self::RunSpeedToSet, 1.0, 5.0, nullptr);
                                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.0f);
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() - 77.0f);
                                    if (ImGui::Button(("Set Healh"), ImVec2(247, 20))) {

                                        settings::self::set_health = true;
                                    }
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() - 77.0f);
                                    if (ImGui::Button(("Set Armor"), ImVec2(247, 20))) {

                                        settings::self::set_armor = true;
                                    }
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }
                        if (selfsubtab == 2)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            ImGui::customchild("List", ImVec2(ImGui::GetWindowWidth() - 400, 380));
                            {
                                ImGui::SetCursorPos(ImVec2(10, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    hk_World* World = (hk_World*)*(uint64_t*)(FiveM::World);
                                    if (!World)
                                        return true;
                                    hk_Ped* LocalPlayer = World->LocalPlayer();
                                    if (!World)
                                        return true;

                                    if (LocalPlayer) {

                                        hk_ObjectNavigationPed* Nav = LocalPlayer->ObjectNavigation();
                                        //if (!Nav)
                                           // return;

                                        hk_ReplayInterface* ReplayInterface = (hk_ReplayInterface*)*(uint64_t*)(FiveM::ReplayInterface);
                                        //  if (!ReplayInterface)
                                           //  return;

                                        hk_PedInterface* PedInterface = ReplayInterface->PedInterface();
                                        // if (!PedInterface)
                                           //  return;

                                        if (ImGui::ListBoxHeader("    ", ImVec2(220, 300))) {
                                            for (int i = 0; i < PedInterface->PedMaximum(); i++) {

                                                hk_Ped* Peds = PedInterface->PedList()->Ped(i);
                                                if (!Peds)
                                                    continue;
                                                //   int PlayerID = FiveM::pointer_to_handle((DWORD64)Peds);
                                                void* m_net_player_data = (void*)(Peds->PlayerInfo() + 0x20);
                                                bool IsPed = false;


                                                auto playerName = FiveM::getpname(m_net_player_data);
                                                const char* c = playerName;
                                                const char* items[] = { c };

                                                auto ped_type = Peds->GetPedType();
                                                if (!ped_type) {
                                                    continue;
                                                }
                                                ped_type = ped_type << 11 >> 25;

                                                if (ped_type != 2) {
                                                    IsPed = true;

                                                }

                                                if (IsPed)
                                                {
                                                    continue;
                                                }
                                                bool is_selected = (selected_index == i);
                                                if (ImGui::Selectable(playerName, is_selected)) {

                                                    selected_index = i;
                                                }
                                            }

                                            ImGui::ListBoxFooter();
                                        }

                                        hk_Ped* SelectedPed = PedInterface->PedList()->Ped(selected_index);
                                    }
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Options", ImVec2(ImGui::GetWindowWidth() - 400, 380));
                            {
                                //  ImGui::SetCursorPos(ImVec2(10, 70));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    hk_World* World = (hk_World*)*(uint64_t*)(FiveM::World);
                                    // if (!World)
                                       //  return;
                                    hk_Ped* LocalPlayer = World->LocalPlayer();

                                    if (LocalPlayer) {

                                        hk_ObjectNavigationPed* Nav = LocalPlayer->ObjectNavigation();
                                        //  if (!Nav)
                                            //  return;

                                        hk_ReplayInterface* ReplayInterface = (hk_ReplayInterface*)*(uint64_t*)(FiveM::ReplayInterface);
                                        //  if (!ReplayInterface)
                                             // return;

                                        hk_PedInterface* PedInterface = ReplayInterface->PedInterface();
                                        //   if (!PedInterface)
                                              // return;

                                        hk_Ped* SelectedPed = PedInterface->PedList()->Ped(selected_index);

                                        if (SelectedPed->GetCoordinate().x != 0) {
                                            std::string healthtoshow = "Health Of Player : " + std::to_string(SelectedPed->GetHealth());
                                            ImGui::Text(healthtoshow.c_str());

                                            if (ImGui::Button("Teleport To Player")) {
                                                if (SelectedPed != LocalPlayer) {
                                                    Nav->SetRotation({ 0, 0, 0, 0 });
                                                    LocalPlayer->SetVelocity();
                                                    LocalPlayer->SetCoordinate(SelectedPed->GetCoordinate());
                                                    Nav->SetCoordinate(SelectedPed->GetCoordinate());
                                                }
                                            }
                                            if (ImGui::Button("Test")) {
                                                if (SelectedPed != LocalPlayer) {
                                                    SelectedPed->SetHealth(-100);
                                                }
                                            }



                                            void* m_net_player_data = (void*)(SelectedPed->PlayerInfo() + 0x20);
                                            auto it = std::find(FiveM::Friend.begin(), FiveM::Friend.end(), FiveM::getpname(m_net_player_data));
                                            if (it != FiveM::Friend.end()) {
                                                if (ImGui::Button("Remove Friend")) {
                                                    // auto it = std::find(FiveM::Friend.begin( ), FiveM::Friend.end( ), (DWORD64)SelectedPed);
                                                    int index = it - FiveM::Friend.begin();
                                                    FiveM::Friend.erase(FiveM::Friend.begin() + index);
                                                }
                                            }
                                            else {
                                                if (ImGui::Button("Add Friend")) {
                                                    FiveM::Friend.push_back(FiveM::getpname(m_net_player_data));
                                                }
                                            }
                                        }
                                    }
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }
                    }
                    if (tab == 4)
                    {
                        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[5]); 
                        ImGui::SetCursorPos(ImVec2(200, 10)); 
                        ImGui::PushStyleColor(ImGuiCol_Text, vehiclesubtab == 1 ? active2 : inactive);
                        CenterTextEx("Vehicle", 1000.3, 10.0f);  
                        if (ImGui::IsItemClicked()) vehiclesubtab = 1;
                        ImGui::SetCursorPos(ImVec2(200, 10)); 
                        ImGui::PushStyleColor(ImGuiCol_Text, vehiclesubtab == 2 ? active2 : inactive); 
                        CenterTextEx("Vehicle List", 1200.3, 10.0f); 
                        if (ImGui::IsItemClicked()) vehiclesubtab = 2;
                        ImGui::PopStyleColor(2); 
                        ImGui::PopFont(); 

                        if (vehiclesubtab == 1)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            ImGui::customchild("General", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                   // ImGui::Checkbox(("Boost"), &settings::vehicle::vehicle_speed_bool);   
                                  //  ImGui::Checkbox(("Eng"), &settings::vehicle::EngineBoost);   
                                /*    ImGui::Checkbox(("Brake"), &settings::vehicle::vehiclebrake);
                                    ImGui::Checkbox(("Jump"), &settings::vehicle::vehiclejump);
                                    ImGui::Checkbox(("Mass"), &settings::vehicle::vehiclemass);
                                    ImGui::Checkbox(("Shift boost"), &settings::vehicle::shiftboost);*/
                                    //ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.0f);
                                   // ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 20.0f);
                                    //float rounding = 10.0f;
                                    //ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, rounding);
                                   /* if (ImGui::Button("Repair Vehicle", ImVec2(247, 20)))
                                    {
                                        settings::vehicle::vehicle_repair = true;
                                    }*/
                                   /*ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 20.0f);
                                    if (ImGui::Button("Color Vehicle", ImVec2(247, 20))) {
                                        settings::vehicle::vehicleprimcolor = true;
                                    }*/
                                  //  ImGui::PopStyleVar(); 
                                    //ImGui::Hotkey(("Hotkey :   "), &settings::self::hotkey_vehicle, ImVec2(150, 20));
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Settings", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(88, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                   // ImGui::SliderInt((("Boost Speed")), &settings::vehicle::vehicle_speed_value, 0, 1000, nullptr);
                                 /*  ImGui::SliderInt((("Brake Speed")), &settings::vehicle::vehicle_brake_value, 0, 1000, nullptr);
                                    ImGui::SliderInt((("Mass")), &settings::vehicle::vehicle_mass_value, 0, 1000, nullptr); */
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }
                        if (vehiclesubtab == 2)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            ImGui::customchild("List", ImVec2(ImGui::GetWindowWidth() - 400, 380));
                            {
                                ImGui::SetCursorPos(ImVec2(10, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]); 
                                    hk_World* World = (hk_World*)*(uint64_t*)(FiveM::World);
                                   // if (!World)
                                        //return;
                                    hk_Ped* LocalPlayer = World->LocalPlayer();

                                    if (LocalPlayer) {

                                        hk_ObjectNavigationPed* Nav = LocalPlayer->ObjectNavigation();
                                        //if (!Nav)
                                          //  return;

                                        hk_ReplayInterface* ReplayInterface = (hk_ReplayInterface*)*(uint64_t*)(FiveM::ReplayInterface);
                                       // if (!ReplayInterface)
                                           // return;

                                        hk_VehicleInterface* VehicleInterface = ReplayInterface->VehicleInterface();
                                        //if (!VehicleInterface)
                                            //return;

                                        if (ImGui::ListBoxHeader("    ", ImVec2(220, 300))) {
                                            for (int i = 0; i < VehicleInterface->VehicleMaximum(); i++) {

                                                hk_Vehicle* Peds = VehicleInterface->VehicleList()->Vehicle(i);
                                                if (!Peds)
                                                    continue;
                                                auto playerName = Peds->VehicleModelInfo()->GetCharName();
                                                const char* c = playerName;
                                                const char* items[] = { c };

                                                std::string VehicleName = playerName;
                                                VehicleName.append("#");
                                                VehicleName.append(std::to_string(i));
                                                bool is_selected = (selectedVeh_index == i);
                                                if (ImGui::Selectable(VehicleName.c_str(), is_selected)) {

                                                    selectedVeh_index = i;
                                                }
                                            }

                                            ImGui::ListBoxFooter();
                                        }

                                        std::string SelectedString = "Vehicle selected : " + std::to_string(selectedVeh_index);
                                        ImGui::Text(SelectedString.c_str());

                                    }
                                    ImGui::PopFont();

                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Options", ImVec2(ImGui::GetWindowWidth() - 400, 380));
                            {
                                //  ImGui::SetCursorPos(ImVec2(10, 70));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                        hk_World* World = (hk_World*)*(uint64_t*)(FiveM::World);
                                       // if (!World)
                                           // return;
                                        hk_Ped* LocalPlayer = World->LocalPlayer();

                                        if (LocalPlayer) {

                                            hk_ObjectNavigationPed* Nav = LocalPlayer->ObjectNavigation();
                                           // if (!Nav)
                                              //  return;

                                            hk_ReplayInterface* ReplayInterface = (hk_ReplayInterface*)*(uint64_t*)(FiveM::ReplayInterface);
                                            //if (!ReplayInterface)
                                               // return;

                                            hk_VehicleInterface* VehicleInterface = ReplayInterface->VehicleInterface();
                                           // if (!VehicleInterface)
                                               // return;
                                            hk_Vehicle* SelectedPed = VehicleInterface->VehicleList()->Vehicle(selectedVeh_index);

                                            if (SelectedPed->GetCoordinate().x != 0) {
                                                std::string healthtoshow = "Health Of Vehicle: " + std::to_string(SelectedPed->GetHealth());
                                                ImGui::Text(healthtoshow.c_str());
                                                std::string coordstoshow = "X : " + std::to_string(SelectedPed->GetCoordinate().x) + "\n  Y : " + std::to_string(SelectedPed->GetCoordinate().y) + "\n  Z : " + std::to_string(SelectedPed->GetCoordinate().z);
                                                ImGui::Text(coordstoshow.c_str());
                                                if (ImGui::Button("Teleport To Vehicle")) {

                                                    Nav->SetRotation({ 0, 0, 0, 0 });
                                                    LocalPlayer->SetVelocity();
                                                    LocalPlayer->SetCoordinate(SelectedPed->GetCoordinate());
                                                    Nav->SetCoordinate(SelectedPed->GetCoordinate());
                                                }
                                            }
                                            else {
                                                ImGui::Text("You are not ingame");
                                            }
                                        }

                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }
                    }
                    if (tab == 5)
                    {
                        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[5]);
                        ImGui::SetCursorPos(ImVec2(200, 10));
                        ImGui::PushStyleColor(ImGuiCol_Text, miscsubtab == 1 ? active2 : inactive);
                        CenterTextEx("Misc", 1000.3, 10.0f);
                        if (ImGui::IsItemClicked()) miscsubtab = 1;
                        ImGui::SetCursorPos(ImVec2(200, 10));
                        ImGui::PushStyleColor(ImGuiCol_Text, miscsubtab == 2 ? active2 : inactive);
                        CenterTextEx("Extinction", 1200.3, 10.0f);
                        if (ImGui::IsItemClicked()) miscsubtab = 2;
                        ImGui::PopStyleColor(2);
                        ImGui::PopFont();

                        if (miscsubtab == 1)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            ImGui::customchild("Misc", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);

                                    ImGui::Checkbox(("Watermark"), &settings::visuals::watermark);

                                    ImGui::Checkbox(("Crosshair"), &settings::visuals::crosshair);

                                    if (settings::visuals::crosshair)
                                    {
                                        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 18.0f);
                                        ImGui::Combo(("##Crosshair Style"), &settings::visuals::crossahir_style, settings::visuals::sss, IM_ARRAYSIZE(settings::visuals::sss));
                                       
                                    }


                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 20.0f);
                                    ImGui::Hotkey("Menu Key:", &Menu::menu_key, ImVec2(150, 20));

                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SameLine();
                            ImGui::customchild("Config", ImVec2(ImGui::GetWindowWidth() - 400, 380));
                            {
                                ImGui::SetCursorPos(ImVec2(10, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);

                                    ImVec2 inputSize(252, 40); 
                                    const float desiredWidth = 250.0f;

                                    ImGui::PushItemWidth(desiredWidth);
                                    ImGui::InputText(skCrypt("##cfg"), settings::visuals::cfg_name, IM_ARRAYSIZE(settings::visuals::cfg_name));
                                    ImGui::PopItemWidth();
                                    
                                    ImGui::NewLine();
                                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 10.0f); 
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 1.0f);
                                    if (ImGui::Button(skCrypt("Load CFG"), ImVec2(247, 20)))
                                    {
                                        // declare file stream
                                        FILE* p_stream4;

                                        // open file for (extended) reading
                                        fopen_s(&p_stream4, settings::visuals::cfg_name, "r+"); 

                                        // set file pointer to 0
                                        fseek(p_stream4, 0, SEEK_SET);

                                        // Player
                                        fread_s(&settings::self::enabled, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::self::godmode, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::self::semigodmode, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::self::noclip, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::self::HotkeyArmor, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::self::HotkeyHealth, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::self::noclipspeed, sizeof(bool), sizeof(bool), 1, p_stream4);

                                        //Weapon

                                        fread_s(&settings::weapon::enabled, sizeof(bool), sizeof(bool), 1, p_stream4);

                                        fread_s(&settings::weapon::no_recoil, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::no_reload, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::no_spread, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::infinite_range, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::infite_ammo, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::damage_boost, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::recoil_value, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::spread_value, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::weapon_range, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::ammo_to_set, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::int_damage, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::custom_fov, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::weapon::scope_fov_value, sizeof(bool), sizeof(bool), 1, p_stream4);

                                        //Aimbot
                                        fread_s(&settings::aimbot::enabled, sizeof(bool), sizeof(bool), 1, p_stream4);

                                        fread_s(&settings::aimbot::aimbot_fov, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::aimbot::smoothhorizontal, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::aimbot::smoothvertical, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::aimbot::aimbot_distance, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::aimbot::aimbot_target, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::aimbot::hotkey, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::aimbot::aimbot_bone, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::aimbot::aimbot_type, sizeof(bool), sizeof(bool), 1, p_stream4); 
                                        fread_s(&settings::aimbot::aimbot_selection, sizeof(bool), sizeof(bool), 1, p_stream4); 


                                        //Visuals

                                        fread_s(&settings::visuals::enabled, sizeof(bool), sizeof(bool), 1, p_stream4);

                                        fread_s(&settings::visuals::master_switch, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::box, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::box_round, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::filled, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::playername, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::weapon_name, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::snapline, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::healthbar, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::armorbar, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::dont_draw_distance, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::circle_at_middle, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::skeleton, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::watermark, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::render_distance, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::draw_dead, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::draw_ped, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::draw_self, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::preview_target, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::draw_fov, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::filled_fov, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::crosshair, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::visuals::crossahir_style, sizeof(bool), sizeof(bool), 1, p_stream4);


                                        // Vehicle
                                        fread_s(&settings::vehicle::vehicle_esp, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::vehicle::vehicle_distance, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::vehicle::vehicle_health, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::vehicle::vehicle_snapline, sizeof(bool), sizeof(bool), 1, p_stream4);

                                        // Object
                                        fread_s(&settings::object::object_distance, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::object::object_esp, sizeof(bool), sizeof(bool), 1, p_stream4);
                                        fread_s(&settings::object::object_snapline, sizeof(bool), sizeof(bool), 1, p_stream4);


                                        fclose(p_stream4);
                                    }


                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 1.0f); 
                                    if (ImGui::Button(skCrypt("Save CFG"), ImVec2(247, 20))) 
                                    {

                                        // declare file stream
                                        FILE* p_stream4;

                                        // open file for (extended) writing
                                        fopen_s(&p_stream4, settings::visuals::cfg_name, "w+");

                                        // set file pointer to 0
                                        fseek(p_stream4, 0, SEEK_SET);

                                        //PLAYER ::
                                        fwrite(&settings::self::enabled, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::self::godmode, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::self::semigodmode, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::self::noclip, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::self::HotkeyArmor, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::self::HotkeyHealth, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::self::noclipspeed, sizeof(bool), 1, p_stream4);

                                        // Weapon
                                        fwrite(&settings::weapon::enabled, sizeof(bool), 1, p_stream4);

                                        fwrite(&settings::weapon::no_recoil, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::no_reload, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::no_spread, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::infinite_range, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::infite_ammo, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::damage_boost, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::recoil_value, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::spread_value, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::weapon_range, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::ammo_to_set, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::int_damage, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::custom_fov, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::weapon::scope_fov_value, sizeof(bool), 1, p_stream4);

                                        // Aimbot
                                        fwrite(&settings::aimbot::enabled, sizeof(bool), 1, p_stream4);

                                        fwrite(&settings::aimbot::aimbot_fov, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::aimbot::smoothhorizontal, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::aimbot::smoothvertical, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::aimbot::aimbot_distance, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::aimbot::aimbot_target, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::aimbot::hotkey, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::aimbot::aimbot_bone, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::aimbot::aimbot_type, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::aimbot::aimbot_selection, sizeof(bool), 1, p_stream4);

                        
                                        //Visuals

                                        fwrite(&settings::visuals::enabled, sizeof(bool), 1, p_stream4);

                                        fwrite(&settings::visuals::master_switch, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::box, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::box_round, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::filled, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::playername, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::playername, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::weapon_name, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::snapline, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::healthbar, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::armorbar, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::dont_draw_distance, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::circle_at_middle, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::skeleton, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::watermark, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::render_distance, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::draw_dead, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::draw_ped, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::draw_self, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::preview_target, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::draw_fov, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::filled_fov, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::crosshair, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::visuals::crossahir_style, sizeof(bool), 1, p_stream4);



                                        fwrite(&settings::vehicle::vehicle_esp, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::vehicle::vehicle_distance, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::vehicle::vehicle_health, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::vehicle::vehicle_snapline, sizeof(bool), 1, p_stream4);

                                        // Object
                                        fwrite(&settings::object::object_distance, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::object::object_esp, sizeof(bool), 1, p_stream4);
                                        fwrite(&settings::object::object_snapline, sizeof(bool), 1, p_stream4);


                                        fclose(p_stream4);
                                    }

                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }
                        if (miscsubtab == 2)
                        {
                            ImGui::SetCursorPos(ImVec2(80, 70));
                            ImGui::customchild("General", ImVec2(ImGui::GetWindowWidth() - 400, 200));
                            {
                                ImGui::SetCursorPos(ImVec2(-9, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::Checkbox(("Auto Farm"), &settings::self::autoarm);
                                    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 130.0f); 
                                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 30.0f); 
                                    ImGui::Hotkey(("##Farm"), &settings::self::hotkey_autofarm, ImVec2(150, 20));
                                    ImGui::Checkbox(("Enabled"), &settings::object::object_esp); 
                                    ImGui::Checkbox(("Loot Bag Name"), &settings::object::object_name);
                                    ImGui::Checkbox(("Loot Bag Distance"), &settings::object::object_distance);                        
                                    ImGui::Checkbox(("Loot Bag Snapline"), &settings::object::object_snapline);
                                    ImGui::Checkbox(("Loot Bag Marker"), &settings::object::object_marker);
             
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SameLine(0, 20);
                            ImGui::customchild("Settings", ImVec2(ImGui::GetWindowWidth() - 400, 150));
                            {
                                ImGui::SetCursorPos(ImVec2(88, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::SliderInt(("Render Distance"), &settings::visuals::lootbag_distance, 0, 1000);
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                            ImGui::SetCursorPos(ImVec2(80, 300));
                            ImGui::customchild("Color", ImVec2(ImGui::GetWindowWidth() - 400, 150));
                            {
                                ImGui::SetCursorPos(ImVec2(10, 40));
                                ImGui::BeginGroup();
                                {
                                    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
                                    ImGui::SetCursorPosY(35.0f);
                                    ImGui::Text("Name");
                                    ImGui::SetCursorPos(ImVec2(241, 35));
                                    ImGui::ColorEdit4((("##na124141me")), settings::tempcolor::bag_espg, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::bag_esp_color.Value.x = settings::tempcolor::bag_espg[0];
                                    settings::visuals::bag_esp_color.Value.y = settings::tempcolor::bag_espg[1];
                                    settings::visuals::bag_esp_color.Value.z = settings::tempcolor::bag_espg[2];
                                    settings::visuals::bag_esp_color.Value.w = settings::tempcolor::bag_espg[3];
                                    ImGui::SetCursorPosY(55.0f);
                                    ImGui::Text("Distance");
                                    ImGui::SetCursorPos(ImVec2(241, 55));
                                    ImGui::ColorEdit4((("##name32532")), settings::tempcolor::bagdistanccolor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::bagdistance_esp_color.Value.x = settings::tempcolor::bagdistanccolor[0];
                                    settings::visuals::bagdistance_esp_color.Value.y = settings::tempcolor::bagdistanccolor[1];
                                    settings::visuals::bagdistance_esp_color.Value.z = settings::tempcolor::bagdistanccolor[2];
                                    settings::visuals::bagdistance_esp_color.Value.w = settings::tempcolor::bagdistanccolor[3];
                                    ImGui::SetCursorPosY(75.0f);
                                    ImGui::Text("Marker");
                                    ImGui::SetCursorPos(ImVec2(241, 75));
                                    ImGui::ColorEdit4((("##57574523141name")), settings::tempcolor::bagmarker, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                                    settings::visuals::bagmarker_esp_color.Value.x = settings::tempcolor::bagmarker[0];
                                    settings::visuals::bagmarker_esp_color.Value.y = settings::tempcolor::bagmarker[1];
                                    settings::visuals::bagmarker_esp_color.Value.z = settings::tempcolor::bagmarker[2];
                                    settings::visuals::bagmarker_esp_color.Value.w = settings::tempcolor::bagmarker[3];                          
                                    ImGui::PopFont();
                                }
                                ImGui::EndGroup();
                            }
                            ImGui::customendchild();
                        }

                    }

		        }
		        ImGui::End();

	        }
	        ImGui::Render();
        }
    }

	pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
	return oPresent(pSwapChain, SyncInterval, Flags);
} 

DWORD WINAPI MainThread(LPVOID lpReserved)
{
	bool init_hook = false;
	do
	{
		if (kiero::init(kiero::RenderType::D3D11) == kiero::Status::Success)
		{
			kiero::bind(8, (void**)& oPresent, hkPresent);
			init_hook = true;
		}
	} while (!init_hook);
	return TRUE;
}

static uint64_t imgbase() {
    return *(uint64_t*)(__readgsqword(0x60) + 0x10);
}

BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved) //all offsets are prolly not updated make sure to update em also you gotta change some stuff in the source to make it work again since fivem did some update shit what makes its harder to use this cheat :))
{
    auto baseaddr = imgbase();
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		DisableThreadLibraryCalls(hMod);
		CreateThread(nullptr, 0, MainThread, hMod, 0, nullptr);
        FiveM::getpname = reinterpret_cast<decltype(FiveM::getpname)>((uint64_t)GetModuleHandleA("citizen-playernames-five.dll") + 0x14F70); //ndyjan1337 was here
        FiveM::FiveM_2802 = false;
        FiveM::FiveM_b2944 = false;
        if (SAFE_CALL(GetModuleHandleA)("FiveM_b2802_GameProcess.exe") || SAFE_CALL(GetModuleHandleA)("FiveM_b2802_GTAProcess.exe")) {
            FiveM::EntityType = 0x1098;
            FiveM::Armor = 0x150C;
            FiveM::freeze = 0x250;
            FiveM::WeaponManager = 0x10B8;
            FiveM::PlayerInfo = 0x10A8;
            FiveM::Recoil = 0x2F4;
            FiveM::Spread = 0x84;
            FiveM::ReloadMultiplier = 0x134;
            FiveM::AmmoType = 0x20;
            FiveM::AmmoExplosiveType = 0x24;
            // FiveM::m_player_id = 0x88;

            FiveM::WeaponName = 0x5F0;
            FiveM::IsInAVehicule = 0x146B;
            FiveM::Range = 0x28C;
            FiveM::FiveM_2802 = true;
            //  FiveM::m_frame_flags = 0x0218;


            FiveM::World = baseaddr + 0x254D448;
            FiveM::ReplayInterface = baseaddr + 0x1F5B820;
            FiveM::Camera = baseaddr + 0x1FBCCD8;
            FiveM::ViewPort = baseaddr + 0x1FBC100;

        }

        if (SAFE_CALL(GetModuleHandleA)("FiveM_b2699_GTAProcess.exe") || SAFE_CALL(GetModuleHandleA)("FiveM_b2699_GameProcess.exe")) {//ndyjan1337 was here
            FiveM::EntityType = 0x10B8;
            FiveM::Armor = 0x1530;
            FiveM::freeze = 0x238;
            FiveM::WeaponManager = 0x10D8;
            FiveM::PlayerInfo = 0x10C8;
            FiveM::Recoil = 0x2F4;
            FiveM::Spread = 0x84;
            FiveM::ReloadMultiplier = 0x134;
            FiveM::AmmoType = 0x20;
            FiveM::AmmoExplosiveType = 0x24;
            FiveM::WeaponName = 0x5F0;
            FiveM::IsInAVehicule = 0x146B;
            FiveM::Range = 0x28C;
            //  FiveM::m_player_id = 0x88;
            //  FiveM::m_frame_flags = 0x0218;
            FiveM::World = baseaddr + 0x26684D8;
            FiveM::ReplayInterface = baseaddr + 0x20304C8;
            FiveM::Camera = baseaddr + 0x20D9868;
            FiveM::ViewPort = baseaddr + 0x20D8C90;
        }
        if (SAFE_CALL(GetModuleHandleA)("FiveM_b2612_GameProcess.exe") || SAFE_CALL(GetModuleHandleA)("FiveM_b2612_GTAProcess.exe")) {//ndyjan1337 was here
            FiveM::EntityType = 0x10B8;
            FiveM::Armor = 0x1530;
            FiveM::freeze = 0x238;
            FiveM::WeaponManager = 0x10D8;
            FiveM::PlayerInfo = 0x10C8;
            FiveM::Recoil = 0x2F4;
            FiveM::Spread = 0x84;
            FiveM::ReloadMultiplier = 0x134;
            FiveM::AmmoType = 0x20;
            FiveM::AmmoExplosiveType = 0x24;
            FiveM::WeaponName = 0x5F0;
            FiveM::IsInAVehicule = 0x146B;
            FiveM::Range = 0x28C;
            //  FiveM::m_player_id = 0x88;
            //  FiveM::m_frame_flags = 0x0218;
            FiveM::World = baseaddr + 0x2567DB0;
            FiveM::ReplayInterface = baseaddr + 0x1F77EF0;
            FiveM::Camera = baseaddr + 0x1FD9148;
            FiveM::ViewPort = baseaddr + 0x1FD8570;
        }
        if (SAFE_CALL(GetModuleHandleA)("FiveM_b2545_GameProcess.exe") || SAFE_CALL(GetModuleHandleA)("FiveM_b2545_GTAProcess.exe")) {//ndyjan1337 was here
            FiveM::EntityType = 0x10B8;
            FiveM::Armor = 0x14E0 + 0x50;
            FiveM::freeze = 0x238;
            FiveM::WeaponManager = 0x10D8;
            FiveM::PlayerInfo = 0x10C8;
            FiveM::Recoil = 0x2F4;
            FiveM::Spread = 0x84;
            FiveM::ReloadMultiplier = 0x134;
            FiveM::AmmoType = 0x20;
            FiveM::AmmoExplosiveType = 0x24;
            FiveM::WeaponName = 0x5F0;
            FiveM::IsInAVehicule = 0x146B;
            FiveM::Range = 0x28C;
            //  FiveM::m_player_id = 0x88;
            //  FiveM::m_frame_flags = 0x0218;
            FiveM::World = baseaddr + 0x25667E8;
            FiveM::ReplayInterface = baseaddr + 0x1F2E7A8;
            FiveM::Camera = baseaddr + 0x1FD7B48;
            FiveM::ViewPort = baseaddr + 0x1FD6F70;
        }
        if (SAFE_CALL(GetModuleHandleA)("FiveM_b2372_GameProcess.exe") || SAFE_CALL(GetModuleHandleA)("FiveM_b2372_GTAProcess.exe")) {//ndyjan1337 was here
            FiveM::EntityType = 0x10B8;
            FiveM::Armor = 0x14E0;
            FiveM::freeze = 0x218;
            FiveM::WeaponManager = 0x10D8;
            FiveM::PlayerInfo = 0x10C8;
            FiveM::Recoil = 0x2F4;
            FiveM::Spread = 0x84;
            FiveM::ReloadMultiplier = 0x134;
            FiveM::AmmoType = 0x20;
            FiveM::AmmoExplosiveType = 0x24;
            FiveM::WeaponName = 0x5F0;
            FiveM::IsInAVehicule = 0x146B;
            FiveM::Range = 0x28C;
            FiveM::World = baseaddr + 0x252DCD8;
            FiveM::ReplayInterface = baseaddr + 0x1F05208;

            FiveM::Camera = baseaddr + 0x1F9F5C8;
            FiveM::ViewPort = baseaddr + 0x1F9E9F0;
        }
        if (SAFE_CALL(GetModuleHandleA)("FiveM_b2189_GameProcess.exe") || SAFE_CALL(GetModuleHandleA)("FiveM_b2189_GTAProcess.exe")) {//ndyjan1337 was here
            FiveM::EntityType = 0x10B8;
            FiveM::Armor = 0x14E0;
            FiveM::freeze = 0x218;
            FiveM::WeaponManager = 0x10D8;
            FiveM::PlayerInfo = 0x10C8;
            FiveM::Recoil = 0x2F4;
            FiveM::Spread = 0x84;
            FiveM::ReloadMultiplier = 0x134;
            FiveM::AmmoType = 0x20;
            FiveM::EngineHealth = 0x908;
            FiveM::AmmoExplosiveType = 0x24;
            FiveM::WeaponName = 0x5F0;
            FiveM::IsInAVehicule = 0x146B;
            FiveM::Range = 0x28C;
            /*   FiveM::m_player_id = 0x68;
               FiveM::m_frame_flags = 0x0218;*/
            FiveM::World = baseaddr + 0x24E6D90;
            FiveM::ReplayInterface = baseaddr + 0x1EE18A8;
            FiveM::Camera = baseaddr + 0x1F89498;
            FiveM::ViewPort = baseaddr + 0x1F888C0;
        }
        if (SAFE_CALL(GetModuleHandleA)("FiveM_b2060_GameProcess.exe") || SAFE_CALL(GetModuleHandleA)("FiveM_b2060_GTAProcess.exe")) {//ndyjan1337 was here
            FiveM::EntityType = 0x10A8;
            FiveM::Armor = 0x14E0;
            FiveM::freeze = 0x218;
            FiveM::WeaponManager = 0x10D8;
            FiveM::PlayerInfo = 0x10B8;
            FiveM::Recoil = 0x2F4;
            FiveM::Spread = 0x84;
            FiveM::ReloadMultiplier = 0x134;
            FiveM::AmmoType = 0x20;
            FiveM::AmmoExplosiveType = 0x24;

            FiveM::WeaponName = 0x5F0;
            FiveM::IsInAVehicule = 0x146B;
            FiveM::Range = 0x28C;
            /*  FiveM::m_player_id = 0x88;
              FiveM::m_frame_flags = 0x0218;*/
            FiveM::World = baseaddr + 0x24C8858;
            FiveM::ReplayInterface = baseaddr + 0x1EC3828;
            FiveM::Camera = baseaddr + 0x1F6B3C0;
            FiveM::ViewPort = baseaddr + 0x1F6A7E0;
        }

        if (SAFE_CALL(GetModuleHandleA)("FiveM_GameProcess.exe") || SAFE_CALL(GetModuleHandleA)("FiveM_GTAProcess.exe")) { //ndyjan1337 was here
            FiveM::EntityType = 0x10A8;
            FiveM::Armor = 0x14B8;
            FiveM::freeze = 0x218;
            /*           FiveM::m_player_id = 0x68; */
            FiveM::WeaponManager = 0x10C8;
            FiveM::PlayerInfo = 0x10B8;

            FiveM::Recoil = 0x2E8;
            FiveM::Spread = 0x74;
            FiveM::ReloadMultiplier = 0x12C;
            FiveM::AmmoType = 0x20;
            FiveM::AmmoExplosiveType = 0x24;
            FiveM::WeaponName = 0x5E0;
            FiveM::IsInAVehicule = 0x146B;
            FiveM::Range = 0x25C;
            /*    FiveM::m_frame_flags = 0x01F8;*/
            FiveM::World = baseaddr + 0x247F840;
            FiveM::ReplayInterface = baseaddr + 0x1EFD4C8;
            FiveM::Camera = baseaddr + 0x2088360;
            FiveM::ViewPort = baseaddr + 0x2087780;
        }
		break;
	case DLL_PROCESS_DETACH:
		kiero::shutdown();
		break;
	}
	return TRUE;
}

#define DISABLE_LOGGING_CONSOLE

