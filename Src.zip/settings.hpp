#pragma once
#define to_vec4(r, g, b, a) ImColor(r / 255.f, g / 255.f, b / 255.f, a)
namespace settings {

	namespace aimbot {

		inline bool enabled = false;
		inline bool TriggerBot = false;

		inline int hotkey = 2;

		inline int aimbot_fov = 5;
		inline int smoothhorizontal = 2;
		inline int smoothvertical = 2;

		inline int aimbot_target = 0;
		inline bool ignore_peds = false;
		inline const char* aimbot_target_list[]{ "All", "Only Player", "Only Ped" };

		inline int aimbot_distance = 150;

		inline int aimbot_smooth = 0;

		inline bool distancetestiz = true;

		inline int aimbot_bone = 0;
		inline const char* aimbot_bones_list[]{ "Head", "Neck", "Body" };

		inline int aimbot_type = 1;
		inline const char* aimbot_type_list[]{ "Mouse", "Memory","Silent Aim"};

		inline bool target_lock = false;

		inline bool overide_target = false;
             inline bool view_aim_point = false;

		inline bool auto_shoot = false;

		inline int aimbot_selection = 0;

	}


	namespace visuals {
		inline int menu_alpha = 255;
		inline bool enabled = false;
		inline bool radar = false;
		inline int master_switch = 0;

		inline bool filled = false;

		inline bool box = false;
		inline int box_round = 0;

		inline bool skeleton = false;
		inline bool skeleton1 = false; 
		inline bool armorbar = false;
		inline bool weapon_name = false;
		inline bool playername = false;	
		inline bool playerid = false;
                inline bool healthbar = false;
		inline bool snapline = false;
		inline bool circle_at_middle = false;
		inline bool dont_draw_health = false;
		inline bool dont_draw_distance = false;

		inline bool draw_dead = false;	
		inline bool aim_dead = false;
		inline int dead_opacity = 50;
		inline bool draw_ped = false;
                inline bool draw_self = false;
				int healthbar_style = 0;
		inline bool watermark = true;
		inline int render_distance = 200;
		inline int vehicle_distance = 200;	
		inline int lootbag_distance = 200;
		inline int skeleton_numbers = 0;
                inline int skeleton_numbers1 = 0;
                inline int skeleton_numbers2 = 0;
                inline int skeleton_numbers3 = 0;
                inline int skeleton_numbers4 = 0;
                inline int skeleton_numbers5 = 0;
                inline int skeleton_numbers6 = 0;
                inline int skeleton_numbers7 = 0;
                inline int skeleton_numbers8 = 0;
                inline int skeleton_numbers9 = 0;
		inline bool preview_target = false;
		inline int preview_style = 0;
		inline bool draw_fov = false;
		inline bool filled_fov = false;

		inline const char* ssxs[]{ "Dot", "Line", "Both"};

		inline bool crosshair = false;

                inline bool language = false;
                inline bool darkmode = true;       
				inline bool particles = true;
		inline int crossahir_style = 0;
		inline int HealthbarStyle = 0;


		inline const char* sss[]{"FiveM Reshade Crosshair", "Dot", "Cross"};

			inline int OutlinedText = 0;


		inline const char* OutlinedTextType[]{"Outlined Text 1", "Outlined Text 2"};

		inline int FillBoxAlpha = 70;
		inline ImColor boxcolor = ImColor(255, 255, 255, 255); 
		inline ImColor boxcolordead = ImColor(255, 0, 0, 255);
		inline ImColor InVisible = ImColor(255, 255, 255);
		inline ImColor filledcolor = ImColor(255, 255, 255, 255);
		inline ImColor cornercolor = ImColor(33, 140, 176, 255);
		inline ImColor namecolor = ImColor(255, 255, 255, 255);
		inline ImColor skeleton_color = ImColor(255, 255, 255, 255);
         inline ImColor skeletonfriend_color = ImColor(0, 255, 0, 255);
		inline ImColor weapon_color = ImColor(255, 255, 255, 255);
		inline ImColor snapeline_color = ImColor(255, 255, 255, 255);
		inline ImColor distance_color = ImColor(255, 255, 255, 255);	
		inline ImColor head_color = ImColor(255, 255, 255, 255);
		inline ImColor crosshair_color = ImColor(255, 255, 255, 255);
		inline ImColor preview_target_colors = ImColor(255, 255, 255, 255);
		inline ImColor fov_color = ImColor(255, 255, 255, 255);
		//___//
		inline ImColor vehicle_esp_color = ImColor(255, 255, 255, 255);
		inline ImColor vehiclebroken_esp_color = ImColor(255, 255, 255, 255);
	
		inline ImColor vehicle_esp_health = ImColor(255, 255, 255, 255);
		inline ImColor vehicle_esp_marker = ImColor(255, 255, 255, 255);
		inline ImColor vehicle_esp_distance = ImColor(255, 255, 255, 255);
		//___//
		inline ImColor bag_esp_color = ImColor(255, 255, 255, 255);
		inline ImColor bagdistance_esp_color = ImColor(255, 255, 255, 255);
                inline ImColor bagmarker_esp_color = ImColor(255, 255, 255, 255);
				 float accent_color[4] = { 0, 255, 0, 255 };
    ImColor get_accent_color( float a = 1.f ) {

        return to_vec4( accent_color[0], accent_color[1], accent_color[2], a );
    }
                inline char cfg_name[10] = "";

	}

	namespace vehicle {

		inline bool repair = false;
        inline bool vehicle_speed_bool = false;    
		inline bool EngineBoost = 1000;
		inline bool vehicle_repair = false;
        inline int vehicle_speed_value = 0;
		inline bool vehicle_esp = false;
		inline bool vehicle_name = false;
		inline bool vehicleprimcolor = false;
		inline bool vehicle_health = false;
		inline bool vehicle_distance = false;
		inline bool vehicle_snapline = false;
		inline bool vehicle_marker = false;
		inline int vehicle_brake_value = 0; 
		inline bool vehiclebrake = false;
		inline bool vehiclejump = false;
		inline bool vehiclemass = false;
		inline int vehicle_mass_value = 0;
		inline bool shiftboost = false;
	}

	namespace object {

		inline bool object_esp = false;

		inline bool object_name = false;	
		inline bool object_distance = false;
		inline bool object_snapline = false;
		inline bool object_marker = false;

	}


	namespace weapon {

		inline bool enabled = false;

		inline bool no_recoil = false;
		inline bool no_reload = false;
		inline bool no_spread = false;
        inline bool explosiveammo = false;
		inline bool explo_meele = false;		
		inline bool weaponfireammo = false;
		inline bool infinite_range = false;

		inline bool infite_ammo = false;
		inline bool set_ammo = false;
		inline bool damage_boost = false;

		inline int recoil_value = 0;
		inline int reload_value = 100;
		inline int spread_value = 0;
		inline int weapon_range = 1000;
		inline int ammo_to_set = 0;
		inline int int_damage = 999;

		inline bool custom_fov = false;
		inline int scope_fov_value = 50;

		inline bool r_custom_fov = false;
		inline int r_scope_fov_value = 90;

		inline bool s_custom_fov = false;
		inline int s_scope_fov_value = 90;
		inline bool ammo = false;
		inline bool rapid = false;
		inline int rapid_int = 1;
	}


	namespace self {

		inline bool enabled = false;
		inline bool autoarm = false;
		inline bool godmode = false;
		inline bool nocol = false;
        inline bool PedList = false;
        inline bool fastrun = false;   
		inline bool revive = false;
		inline bool semigodmode = false;
		inline bool set_armor = false;
		inline bool set_health = false;
		inline bool set_revive = false;
		inline bool noclip = false;
		inline int health = 0;
		inline int armor = 0;
        inline int RunSpeedToSet = 1;
		inline int hotkey_noclip = 0;
        inline int hotkey_blockmenu = 0;
        inline int hotkey_autofarm = 0;
        inline int HotkeyArmor = 0;
        inline int HotkeyHealth = 0;

		inline int hotkey_forward = 0x57;
        inline int hotkey_left = 0x41;
		inline int hotkey_right = 0x44;
        inline int hotkey_backward = 0x53;
                inline bool noclipspeed = false;
                inline float noclipspeedlol = 1.00000f;



		    inline int hotkey_lootbagesp = 0;
            inline int hotkey_vehicleesp = 0;
            inline int hotkey_explosiveammo = 0;
			inline int hotkey_damage = 0;
			inline int hotkey_recoil = 0;
			inline int hotkey_vehicle = 0;
			inline int hotkey_revive = 0;

	}

	namespace radar {

		bool enabled = false;
		bool enable2DRadar = false;

	}

	namespace tempcolor
	{
		inline float box[4] = { 255.f, 255.f, 255.f, 255.f };
		inline float filled[4] = { 255.f, 255.f, 255.f, 125.f };
		inline float corner[4] = { 33.f, 140.f, 176.f, 255.f };
		inline float skeleton[4] = { 255.f, 255.f, 255.f, 255.f };
		inline float weapon[4] = { 33.f, 140.f, 176.f, 255.f };
		inline float head[4] = { 33.f, 140.f, 176.f, 255.f };
		inline float name[4] = { 255.f, 255.f, 255.f, 255.f };
		inline float snapline[4] = { 255.f, 255.f, 255.f, 255.f };
		inline float distance[4] = { 255.f, 255.f, 255.f, 255.f };
		inline float crosshair[4] = { 255.f, 255.f, 255.f, 255.f };
		inline float preview_target[4] = { 255.f, 255.f, 255.f, 255.f };
		inline float fov_color[4] = { 255.f, 255.f, 255.f, 255.f };
		//_//_//_/_/_/_/_/_/_/
		inline float bag_espg[4] = { 255.f, 255.f, 255.f, 255.f };
                inline float vehicle_esp[4] = {255.f, 255.f, 255.f, 255.f};
		inline float bagmarker[4] = {255.f, 255.f, 255.f, 255.f};
        inline float bagdistanccolor[4] = {255.f, 255.f, 255.f, 255.f};
		inline float vehiclebrokencolor[4] = { 255.f, 0.f, 0.f, 255.f };
        inline float vehicleesphealth[4] = {255.f, 255.f, 255.f, 255.f};
        inline float vehiclemarker[4] = {255.f, 255.f, 255.f, 255.f};
        inline float vehicledistance[4] = {255.f, 255.f, 255.f, 255.f};

	}

}
